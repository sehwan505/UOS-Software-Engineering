"use client";

import React from 'react';

export const RightSidebar = () => {
  return (
    <aside className="min-w-80 h-screen py-8 px-4 mx-6">
    </aside>
  );
};

export default RightSidebar;