"use client";
import ApplyQuestion from './ApplyQuestion';
import { QuestionTypes, InputLimits } from '@/define/applyTypes';
import { useState } from 'react';

export const ApplyFormBuilder = ({questions, handleQuestionChange, onClose}) => {
  console.log(questions, handleQuestionChange)
  const [formTitle, setFormTitle] = useState(questions.title);
  const [formDescription, setFormDescription] = useState(questions.description);
  const [updatedQuestions, setUpdatedQuestions] = useState(questions.questions);
  const [newQuestion, setNewQuestion] = useState({
    title: '',
    type: QuestionTypes.TEXT,
    required: false,
    options: [],
  });
  const [isAddingQuestion, setIsAddingQuestion] = useState(false);
  const [newOption, setNewOption] = useState('');

  // 질문 추가 핸들러
  const addQuestion = () => {
    if (newQuestion.title) {
      setUpdatedQuestions([...updatedQuestions, newQuestion]);
      setNewQuestion({
        title: '',
        type: QuestionTypes.TEXT,
        required: false,
        options: [],
      });
      setIsAddingQuestion(false);
      setNewOption('');
    }else{
      alert("제목을 채워주세요");
    }
  };

  // 질문 제거 핸들러
  const removeQuestion = (index) => {
    setUpdatedQuestions(updatedQuestions.filter((_, i) => i !== index));
  };

  // 옵션 추가 핸들러
  const addOption = () => {
    if (newOption) {
      setNewQuestion((prev) => ({ ...prev, options: [...prev.options, newOption] }));
      setNewOption('');
    }else{
      alert("내용을 채워주세요");
    }
  };

  // 옵션 제거 핸들러
  const removeOption = (index) => {
    setNewQuestion((prev) => ({
      ...prev,
      options: prev.options.filter((_, i) => i !== index),
    }));
  };

  // 질문 목록을 저장할 핸들러
  const saveForm = () => {
    const formData = {
      title: formTitle,
      description: formDescription,
      questions: updatedQuestions,
    };
    // TODO: 데이터 업로드 로직 추가
    handleQuestionChange(formData);
    onClose();
  };

  return (
    <div className="shadow-md rounded-lg max-w-3xl mx-auto p-6 bg-white">
            {/* 닫기 버튼 */}
            <button
        onClick={onClose}
        className="absolute top-8 right-8 text-gray-400 hover:text-gray-600 focus:outline-none"
        aria-label="닫기"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          className="h-6 w-6"
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
          strokeWidth={2}
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            d="M6 18L18 6M6 6l12 12"
          />
        </svg>
      </button>

      <h2 className="text-xl font-semibold mb-4">동아리 가입 신청 양식</h2>
      {/* 폼 제목과 설명 */}
      <div className="mb-6">
        <input
          type="text"
          placeholder="제목"
          value={formTitle}
          onChange={(e) => setFormTitle(e.target.value)}
          maxLength={InputLimits.FORM_TITLE} // 글자 수 제한 적용
          className="w-full p-2 mb-2 border border-gray-300 rounded"
        />
        <textarea
          placeholder="설명"
          value={formDescription}
          onChange={(e) => setFormDescription(e.target.value)}
          maxLength={InputLimits.FORM_DESCRIPTION} // 글자 수 제한 적용
          className="w-full p-2 border border-gray-300 rounded"
        />
      </div>

      {/* 기존 질문 목록 */}
      <div className="mb-4">
        <h3 className="text-lg font-semibold mb-2">질문 목록</h3>
        <div className="max-h-64 overflow-y-auto">
          {updatedQuestions && updatedQuestions.map((question, index) => (
            <div key={index} className="relative p-4 mb-2 border rounded shadow-sm bg-gray-50">
              <ApplyQuestion question={question} onChange={undefined} />
              {/* 제거 버튼 */}
              <div className="flex justify-end mt-2">
                <button
                  onClick={() => removeQuestion(index)}
                  className="w-6 h-6 flex items-center justify-center bg-gray-400 text-white rounded hover:bg-gray-500"
                >
                  -
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 새 질문 추가 영역 */}
      {isAddingQuestion ? (
        <div className="mb-4 p-4 border rounded">
          <input
            type="text"
            placeholder="질문 제목"
            value={newQuestion.title}
            onChange={(e) =>
              setNewQuestion((prev) => ({ ...prev, title: e.target.value }))
            }
            maxLength={InputLimits.QUESTION_TITLE} // 글자 수 제한 적용
            className="w-full p-2 mb-2 border border-gray-300 rounded"
          />
          <select
            value={newQuestion.type}
            onChange={(e) =>
              setNewQuestion((prev) => ({ ...prev, type: e.target.value }))
            }
            className="w-full p-2 mb-2 border border-gray-300 rounded"
          >
            <option value={QuestionTypes.TEXT}>문자 입력</option>
            <option value={QuestionTypes.RADIO}>옵션 선택 (단일 선택)</option>
            <option value={QuestionTypes.CHECKBOX}>옵션 선택 (다중 선택)</option>
            <option value={QuestionTypes.DROPDOWN}>드롭다운</option>
          </select>
          <label className="flex items-center mb-2">
            <input
              type="checkbox"
              checked={newQuestion.required}
              onChange={(e) =>
                setNewQuestion((prev) => ({ ...prev, required: e.target.checked }))
              }
              className="mr-2"
            />
            필수 항목
          </label>

          {/* 옵션 입력 영역 */}
          {(newQuestion.type === QuestionTypes.RADIO || newQuestion.type === QuestionTypes.CHECKBOX || newQuestion.type === QuestionTypes.DROPDOWN) && (
            <div className="mb-4">
              <h4 className="text-sm font-semibold mb-2">옵션 항목</h4>
              <div className="relative mb-2">
                <input
                  type="text"
                  placeholder="옵션 항목"
                  value={newOption}
                  onChange={(e) => setNewOption(e.target.value)}
                  maxLength={InputLimits.OPTION_TEXT} // 글자 수 제한 적용
                  className="w-full p-2 pr-10 border border-gray-300 rounded"
                />
                <button
                  onClick={addOption}
                  className="absolute inset-y-0 right-0 px-2 text-lg text-blue-500 hover:text-blue-700"
                >
                  +
                </button>
              </div>
              {/* 기존 옵션 목록 */}
              {newQuestion.options.map((option, index) => (
                <div key={index} className="flex items-center justify-between p-2 mb-2 border rounded">
                  <span>
                    <span className="text-gray-300">{index + 1}.</span>
                    <span className="ml-1">{option}</span>
                  </span>
                  <button
                    onClick={() => removeOption(index)}
                    className="text-lg text-red-500 hover:text-red-700"
                  >
                    -
                  </button>
              </div>
              ))}
            </div>
          )}

          <button
            onClick={addQuestion}
            className="w-full p-2 mb-1 bg-blue-500 text-white rounded hover:bg-blue-600"
          >
            완료
          </button>

          <button
            onClick={() => {
              setIsAddingQuestion(false);
              setNewQuestion({ title: '', type: QuestionTypes.TEXT, required: false, options: [], value: '' });
            }}
            className="w-full p-2 bg-gray-300 text-white rounded hover:bg-gray-500"
          >
            취소
          </button>
        </div>
      ):
      (
        <>
          <button
            onClick={() => setIsAddingQuestion(true)}
            className="shadow-md w-full p-2 bg-blue-500 text-white rounded hover:bg-blue-600 mb-2"
          >
            새 질문 추가
          </button>
        </>
      )
      }

      {/* 저장 버튼 */}
      <button
        onClick={saveForm}
        className="shadow-md w-full p-2 bg-purple-500 text-white rounded hover:bg-purple-600"
      >
        저장
      </button>
    </div>
  );
};

export default ApplyFormBuilder;
