package uniCircle.backend.entity;

public enum Visibility {
    PUBLIC,PRIVATE
}
